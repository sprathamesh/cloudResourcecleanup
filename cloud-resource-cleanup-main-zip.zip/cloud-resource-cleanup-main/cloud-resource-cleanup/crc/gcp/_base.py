# Copyright (c) Yugabyte, Inc.

# A list of GCP regions
GCP_REGION_LIST = [
    "us-east1",
    "asia-east1",
    "asia-northeast1",
    "asia-southeast1",
    "europe-west1",
    "us-central1",
    "us-west1",
]
