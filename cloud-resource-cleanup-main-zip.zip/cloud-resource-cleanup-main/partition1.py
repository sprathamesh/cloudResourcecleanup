import subprocess
from tkinter import *

root = Tk()

#root.geometry("700x700")
#root.minsize(300, 300)
#root.maxsize(800, 800)
root.configure(bg="lightblue")
root.title("CLOUD RESOURCE CLEANUP")

# Create a Canvas widget
canvas = Canvas(root)
canvas.pack(side=RIGHT, fill=BOTH, expand=True)

# Add a Scrollbar to the Canvas
scrollbar = Scrollbar(root, orient=VERTICAL, command=canvas.yview)
scrollbar.pack(side=RIGHT, fill=Y)

# Configure the Canvas to use the Scrollbar
canvas.configure(yscrollcommand=scrollbar.set)
canvas.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

# Create a Frame inside the Canvas to hold the content
content_frame = Frame(canvas, bg="lightblue")

# Add the content_frame to the Canvas
canvas.create_window((0, 0), window=content_frame, anchor="nw")


# Function to submit the form
def submit_form():
    cloud =cloud_var.get()
    resource =resource_var.get()
    filter_tags =text_area1.get(1.0, END)
    age =text_area2.get(1.0, END)
    operation_type =operation_type_var.get()
    dry_run =dry_run_var.get()

    command = ['python', 'crc.py', '--cloud', cloud, '--resource', resource, '--filter_tags', filter_tags, '--age', age, '--operation_type', operation_type, '--' ,dry_run] 
    """command_string = ' '.join(command)
    label1111=Label(text=command_string)
    label1111.pack()"""
    subprocess.run(command)

photo = PhotoImage(file="C:/Users/hp/Pictures/Screenshots/azurepic.png")
resized_photo = photo.subsample(2)
pic_label = Label(image=resized_photo)
pic_label.config(width=100, height=100)
pic_label.pack()

heading = Label(text="Cloud Resource Cleanup in Azure:\nEfficient Management and Optimization of Azure Resources",
                bg="blue", fg="white", font=("Consolas", 12))
heading.pack(padx=20, pady=10)

l1 = Label(text="CLOUD NAME")
l1.pack(side=TOP, anchor="w", padx=20, pady=10)
options1 = ["azure", "aws", "gcp","all"]
cloud_var = StringVar()
dropdown1 = OptionMenu(root, cloud_var, *options1)
dropdown1.pack()

l2 = Label(text="RESOURCE")
l2.pack(side=TOP, anchor="w", padx=20, pady=10)
options2 = ["vm", "ip", "disk"]
resource_var = StringVar()
dropdown2 = OptionMenu(root, resource_var, *options2)
dropdown2.pack()

l3 = Label(text="FILTER TAGS")
l3.pack(side=TOP, anchor="w", padx=20, pady=10)
text1 = "{ 'test_task': ['stress-test'] }"
l10 = Label(text=text1)
l10.pack()
text_area1 = Text(root, height=3, width=40)
text_area1.pack()

l4 = Label(text="AGE")
l4.pack(side=TOP, anchor="w", padx=20, pady=10)
text2 = "{ 'days': 2, 'hours': 12 }"
l11 = Label(text=text2)
l11.pack()
text_area2 = Text(root, height=3, width=40)
text_area2.pack()

l5 = Label(text="OPERATION TYPE")
l5.pack(side=TOP, anchor="w", padx=20, pady=10)
options3 = ["stop", "delete"]
operation_type_var = StringVar()
dropdown3 = OptionMenu(root, operation_type_var, *options3)
dropdown3.pack()

l6 = Label(text="DRY RUN")
l6.pack(side=TOP, anchor="w", padx=20, pady=10)
options4 = ["dry_run"]
dry_run_var = StringVar()
dropdown4 = OptionMenu(root, dry_run_var, *options4)
dropdown4.pack()

submit_button = Button(root, text="SEARCH",width=15, height=2, command=submit_form)
submit_button.pack(pady=10)

reset_button = Button(root, text="Reset",width=15, height=2, command=lambda: [text_area1.delete(1.0, END), text_area2.delete(1.0, END)])
reset_button.pack()

# Update the Canvas scroll region when the content_frame changes
def on_content_frame_change(event):
    canvas.configure(scrollregion=canvas.bbox("all"))

content_frame.bind("<Configure>", on_content_frame_change)

root.mainloop()